(function(cfg) {
  const visible = e => !!e && e.getClientRects().length > 0 && !e.disabled;
  const text = document.body ? document.body.innerText : '';
  const known = /\/a70\.htm$/i.test(location.pathname) || !!document.querySelector('input[name=DDDDD],input[name=upass],input[name=user_account]');
  if (!cfg.test && (!['1.1.1.1','10.10.9.200'].includes(location.hostname) || !known)) return 'WRONG_PAGE';
  const pw = Array.from(document.querySelectorAll('input[type=password]')).find(visible);
  const users = Array.from(document.querySelectorAll('input')).filter(e => visible(e) && ['text','tel','email','number',''].includes((e.type || '').toLowerCase()));
  const user = users.find(e => /DDDDD|username|account|userid|学号/i.test(e.name + ' ' + e.id + ' ' + e.placeholder)) || users[0];
  if (!pw || !user) return /退出|注销|logout|已登录/i.test(text) ? 'SESSION' : 'WAIT';
  if (Array.from(document.querySelectorAll('input')).some(e => visible(e) && /验证码|captcha|checkcode|verifycode/i.test(e.name + ' ' + e.id + ' ' + e.placeholder))) return 'CAPTCHA';
  let select = null, option = null;
  for (const s of Array.from(document.querySelectorAll('select')).filter(visible)) {
    const o = Array.from(s.options).find(o => o.text.includes(cfg.carrier));
    if (o) { select = s; option = o; break; }
  }
  if (!select || !option) return 'CARRIER';
  const button = Array.from(document.querySelectorAll('button,input[type=submit],input[type=button],a')).find(e => visible(e) && /^(登录|登陆|login|连接|上网登录)$/i.test((e.innerText || e.value || '').replace(/\s/g,'')));
  if (!button) return 'BUTTON';
  const set = (e, value) => {
    const proto = e.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto,'value').set.call(e, value);
    for (const name of ['input','change','blur']) e.dispatchEvent(new Event(name,{bubbles:true}));
  };
  set(user, cfg.account); set(pw, cfg.password); set(select, option.value);
  if (cfg.prepare) { window.__campusLoginButton = button; return 'READY'; }
  button.click(); return 'SUBMITTED';
})
