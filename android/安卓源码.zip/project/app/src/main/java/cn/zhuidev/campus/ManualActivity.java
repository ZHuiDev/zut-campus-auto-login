package cn.zhuidev.campus;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public final class ManualActivity extends Activity {
    public static boolean showing;
    private WebView web;
    private ConnectivityManager cm;
    private Network previous;
    private boolean bound;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); showing=true;
        try {
            WifiManager wm=(WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if(wm==null||wm.getConnectionInfo()==null||!Core.SSID.equals(Core.ssid(wm.getConnectionInfo().getSSID()))) throw new IllegalStateException();
            cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            Network wifi=null;
            for(Network n:cm.getAllNetworks()){NetworkCapabilities caps=cm.getNetworkCapabilities(n);if(caps!=null&&caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)){wifi=n;break;}}
            if(wifi==null)throw new IllegalStateException();
            previous=cm.getBoundNetworkForProcess(); if(!cm.bindProcessToNetwork(wifi))throw new IllegalStateException(); bound=true;
            LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setFitsSystemWindows(true);
            TextView title=new TextView(this);title.setText("学校登录页 · 返回即可回到应用");title.setTextSize(16);title.setPadding(24,24,24,24);layout.addView(title);
            web=new WebView(this); LoginEngine.configure(web); web.setWebChromeClient(new WebChromeClient());
            web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return r.isForMainFrame()&&!Core.approved(r.getUrl().toString());}});
            layout.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(layout);web.loadUrl(Core.DIRECT);
        }catch(Exception e){Toast.makeText(this,"请先连接 zut-stu，并授予 Wi-Fi 识别权限",Toast.LENGTH_LONG).show();finish();}
    }
    @Override protected void onDestroy(){
        showing=false;
        if(web!=null){if(web.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)web.getParent()).removeView(web);web.destroy();}
        if(bound&&cm!=null)cm.bindProcessToNetwork(previous);super.onDestroy();
    }
}
