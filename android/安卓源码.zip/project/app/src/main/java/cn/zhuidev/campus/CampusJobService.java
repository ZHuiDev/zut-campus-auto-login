package cn.zhuidev.campus;

import android.app.job.JobParameters;
import android.app.job.JobService;

public final class CampusJobService extends JobService {
    private LoginEngine engine;
    private boolean stopping;
    @Override public boolean onStartJob(JobParameters params) {
        Store store = new Store(this);
        if (store.paused() || !store.ready()) return false;
        if (params.getJobId() == Tasks.DAILY) Tasks.daily(this);
        if (engine != null || LoginEngine.active != null || ManualActivity.showing) return false;
        stopping = false;
        engine = new LoginEngine(this, null, new LoginEngine.Listener() {
            public void log(String s) { }
            public void finished(LoginEngine.Result r) {
                engine = null;
                String status = new Store(CampusJobService.this).p.getString("status", "");
                if (r == LoginEngine.Result.ATTENTION || r == LoginEngine.Result.FAILURE || (r == LoginEngine.Result.SKIP && (status.startsWith("无法读取") || status.startsWith("请先授权")))) Tasks.notifyAttention(CampusJobService.this);
                if (!stopping) jobFinished(params, false);
            }
        });
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> { if (engine != null) engine.start(false); });
        return true;
    }
    @Override public boolean onStopJob(JobParameters params) {
        stopping = true;
        if (engine != null) { LoginEngine current = engine; engine = null; current.cancel(); }
        return false;
    }
}
