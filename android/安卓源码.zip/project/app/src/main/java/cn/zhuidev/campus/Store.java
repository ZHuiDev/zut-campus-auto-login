package cn.zhuidev.campus;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyStore;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public final class Store {
    public final SharedPreferences p;
    public Store(Context c) { p = c.getSharedPreferences("campus-private", Context.MODE_PRIVATE); }
    public String account() { return p.getString("account", ""); }
    public String carrier() { return p.getString("carrier", "联通"); }
    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        String alias = "zut-campus-password-v1";
        if (!ks.containsAlias(alias)) {
            KeyGenerator g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            g.init(new KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            g.generateKey();
        }
        return ((KeyStore.SecretKeyEntry)ks.getEntry(alias, null)).getSecretKey();
    }
    public void credentials(String account, String password, String carrier) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        byte[] encrypted = cipher.doFinal(password.getBytes("UTF-8"));
        if (!p.edit().putString("account", account).putString("carrier", carrier)
                .putString("secret", Base64.encodeToString(encrypted, Base64.NO_WRAP))
                .putString("iv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP)).commit()) throw new java.io.IOException("Save failed");
    }
    public String password() throws Exception {
        String enc = p.getString("secret", ""); if (enc.isEmpty()) return "";
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(p.getString("iv", ""), Base64.NO_WRAP)));
        return new String(cipher.doFinal(Base64.decode(enc, Base64.NO_WRAP)), "UTF-8");
    }
    public boolean ready() { return !account().isEmpty() && !p.getString("secret", "").isEmpty(); }
    public boolean paused() { return p.getBoolean("paused", false); }
    public void reset() { p.edit().putBoolean("paused", false).putInt("failures", 0).apply(); }
    public void pause() { p.edit().putBoolean("paused", true).apply(); }
    public int fail() { int n = p.getInt("failures", 0) + 1; p.edit().putInt("failures", n).putBoolean("paused", n >= 3).apply(); return n; }
    public synchronized void log(String message) {
        String line = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.CHINA).format(new Date()) + "  " + message;
        String old = p.getString("log", "");
        if (old.length() > 10000) old = old.substring(old.length() - 6000);
        p.edit().putString("log", old + line + "\n").putString("status", message).apply();
    }
}
