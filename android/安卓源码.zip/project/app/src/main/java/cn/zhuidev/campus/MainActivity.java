package cn.zhuidev.campus;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

public final class MainActivity extends Activity {
    private Store store;
    private EditText account, password;
    private Spinner carrier, interval;
    private CheckBox reopen, reconnect, daily, boot;
    private Button connect, time;
    private TextView status, logView;
    private FrameLayout portal;
    private LoginEngine engine;
    private int hour = 8, minute;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean firstResume = true;
    private long nextForegroundCheck;
    private static final int GREEN = Color.rgb(20,114,99), INK = Color.rgb(32,49,59), MUTED = Color.rgb(95,113,126);
    private final Runnable refresh = new Runnable() {
        public void run() {
            refreshLog();
            if (engine == null && !store.paused() && store.p.getBoolean("reconnect", false) && System.currentTimeMillis() >= nextForegroundCheck) {
                nextForegroundCheck = System.currentTimeMillis() + 60000;
                connect(false);
            }
            ui.postDelayed(this, 5000);
        }
    };
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private TextView text(LinearLayout parent, String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10);
        parent.addView(t, lp); return t;
    }
    private LinearLayout card(LinearLayout parent) {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(18),dp(18),dp(18),dp(12));
        l.setBackground(bg(Color.WHITE,16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin = dp(16); parent.addView(l,lp); return l;
    }
    private EditText field(LinearLayout parent, String hint, boolean secret) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setTextSize(16); e.setPadding(dp(12),dp(10),dp(12),dp(10));
        e.setInputType(secret ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_CLASS_TEXT);
        e.setBackground(bg(Color.rgb(242,246,247),10)); e.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,dp(50)); lp.bottomMargin = dp(14); parent.addView(e,lp); return e;
    }
    private Button button(LinearLayout parent, String title, boolean primary, View.OnClickListener action) {
        Button b = new Button(this); b.setText(title); b.setTextSize(15); b.setAllCaps(false);
        b.setTextColor(primary ? Color.WHITE : GREEN); b.setBackground(bg(primary ? GREEN : Color.rgb(231,242,239),10)); b.setOnClickListener(action);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,dp(48)); lp.bottomMargin = dp(10); parent.addView(b,lp); return b;
    }
    private CheckBox option(LinearLayout parent, String title) {
        CheckBox b = new CheckBox(this); b.setText(title); b.setTextSize(14); b.setTextColor(INK); parent.addView(b,new LinearLayout.LayoutParams(-1,-2)); return b;
    }
    private Spinner spinner(LinearLayout parent, String[] choices) {
        Spinner s = new Spinner(this); s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,choices));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,dp(48)); lp.bottomMargin = dp(10); parent.addView(s,lp); return s;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); store = new Store(this);
        getWindow().setStatusBarColor(Color.rgb(243,247,248)); getWindow().setNavigationBarColor(Color.rgb(243,247,248));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(Color.rgb(243,247,248));
        LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(20),dp(20),dp(20),dp(24));
        scroll.addView(body); setContentView(scroll);
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            int left, top, right, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets safe = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
                left = safe.left; top = safe.top; right = safe.right; bottom = safe.bottom;
            } else { left = insets.getSystemWindowInsetLeft(); top = insets.getSystemWindowInsetTop(); right = insets.getSystemWindowInsetRight(); bottom = insets.getSystemWindowInsetBottom(); }
            v.setPadding(left,top,right,bottom); return insets;
        });
        text(body,"校园网，一键连接",27,INK,true);
        text(body,"中原工学院  ·  zut-stu  ·  联通",14,MUTED,false);
        LinearLayout credentials = card(body);
        text(credentials,"登录账户",18,INK,true);
        account = field(credentials,"学号 / 账号",false); password = field(credentials,"校园网密码",true);
        text(credentials,"运营商",13,MUTED,false);
        String[] carriers = {"联通","移动","电信","校园单宽","校园内网"};
        carrier = spinner(credentials,carriers);
        account.setText(store.account());
        try { password.setText(store.password()); } catch (Exception e) { store.log("保存的密码无法解密，请重新输入并保存。"); }
        for (int i=0;i<carriers.length;i++) if (carriers[i].equals(store.carrier())) carrier.setSelection(i);
        connect = button(credentials,"保存并连接",true,v -> { if (save()) connect(true); });
        button(credentials,"仅保存设置",false,v -> save());
        text(credentials,"第一次后仍未联网时，再尝试第二次。密码在本机加密保存。",12,MUTED,false);
        LinearLayout options = card(body);
        text(options,"自动连接",18,INK,true);
        reopen = option(options,"打开应用时自动尝试登录"); reopen.setChecked(store.p.getBoolean("reopen",true));
        reconnect = option(options,"后台断线检测（系统调度）"); reconnect.setChecked(store.p.getBoolean("reconnect",false));
        interval = spinner(options,new String[]{"后台检测间隔：15 分钟起","后台检测间隔：30 分钟起","后台检测间隔：60 分钟起","后台检测间隔：120 分钟起"});
        int[] values = {15,30,60,120}; for(int i=0;i<values.length;i++) if(values[i]==store.p.getInt("minutes",15))interval.setSelection(i);
        daily = option(options,"每日定时尝试登录（时间可能延后）"); daily.setChecked(store.p.getBoolean("daily",false));
        hour = store.p.getInt("hour",8); minute = store.p.getInt("minute",0);
        time = button(options,"",false,v -> new TimePickerDialog(this,(picker,h,m)->{hour=h;minute=m;updateTime();},hour,minute,true).show()); updateTime();
        boot = option(options,"重启手机后恢复已启用的后台任务"); boot.setChecked(store.p.getBoolean("boot",false));
        text(options,"后台任务受系统省电策略影响。应用留在前台时，断线检测约每分钟执行一次。",12,MUTED,false);
        button(options,"Wi-Fi 识别授权",false,v -> requestWifiPermission());
        button(options,"后台运行与权限说明",false,v -> backgroundHelp());
        LinearLayout controls = card(body);
        text(controls,"连接状态",18,INK,true);
        status = text(controls,"等待连接",15,GREEN,true);
        portal = new FrameLayout(this); portal.setVisibility(View.GONE); controls.addView(portal,new LinearLayout.LayoutParams(-1,dp(240)));
        button(controls,"查看学校登录页",false,v -> {
            if (engine != null) engine.cancel();
            if (LoginEngine.active != null) LoginEngine.active.cancel();
            startActivity(new Intent(this,ManualActivity.class));
        });
        button(controls,"打开系统 Wi-Fi 设置",false,v -> startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)));
        button(controls,"停止本次及后台任务",false,v -> {
            store.pause(); Tasks.cancel(this); if (LoginEngine.active != null) LoginEngine.active.cancel();
            store.log("自动任务已暂停，点击保存或连接可恢复。"); refreshLog();
        });
        logView = text(controls,"",12,MUTED,false); logView.setTextIsSelectable(true);
        button(controls,"复制状态日志",false,v -> {
            ((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("校园网状态",store.p.getString("log","")));
            Toast.makeText(this,"已复制状态日志，不含账号密码",Toast.LENGTH_SHORT).show();
        });
        text(body,"Android 版 1.0  ·  默认只对 zut-stu 尝试登录",12,MUTED,false);
        Tasks.schedule(this); refreshLog();
    }
    private void updateTime() { time.setText(String.format(Locale.CHINA,"每天 %02d:%02d",hour,minute)); }
    private boolean save() {
        if (account.getText().toString().trim().isEmpty() || password.getText().length()==0) { Toast.makeText(this,"请填写账号和密码",Toast.LENGTH_SHORT).show(); return false; }
        try {
            store.credentials(account.getText().toString().trim(),password.getText().toString(),carrier.getSelectedItem().toString());
            int[] values = {15,30,60,120};
            store.p.edit().putBoolean("reopen",reopen.isChecked()).putBoolean("reconnect",reconnect.isChecked()).putBoolean("daily",daily.isChecked())
                    .putBoolean("boot",boot.isChecked()).putInt("minutes",values[interval.getSelectedItemPosition()]).putInt("hour",hour).putInt("minute",minute).commit();
            store.reset(); Tasks.schedule(this); store.log("设置已保存。 "); refreshLog();
            nextForegroundCheck = System.currentTimeMillis()+60000;
            if ((reconnect.isChecked()||daily.isChecked()) && Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},102);
            return true;
        } catch (Exception e) { store.log("保存失败，请检查设备密钥存储是否可用。 "); refreshLog(); return false; }
    }
    private void connect(boolean manual) {
        if (engine!=null) return;
        if (manual && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) { requestWifiPermission(); return; }
        connect.setEnabled(false);
        engine = new LoginEngine(this,portal,new LoginEngine.Listener() {
            public void log(String s) { refreshLog(); }
            public void finished(LoginEngine.Result r) { engine=null; connect.setEnabled(true); nextForegroundCheck=System.currentTimeMillis()+60000; refreshLog(); }
        });
        engine.start(manual);
    }
    private void refreshLog() {
        if (status==null) return;
        status.setText(store.p.getString("status","先连接 zut-stu，再填写账号并点击连接。"));
        String log = store.p.getString("log","");
        String[] lines=log.split("\n"); StringBuilder tail=new StringBuilder(); for(int i=Math.max(0,lines.length-12);i<lines.length;i++)tail.append(lines[i]).append('\n');
        logView.setText(tail.toString());
    }
    private void requestWifiPermission() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) {
            new AlertDialog.Builder(this).setTitle("Wi-Fi 识别权限已授予").setMessage("如果仍无法读取 zut-stu，请开启手机系统定位。应用只读取已连接的 Wi-Fi 名称，不调用 GPS 定位。")
                    .setPositiveButton("打开定位设置",(d,w)->startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))).setNegativeButton("关闭",null).show(); return;
        }
        new AlertDialog.Builder(this).setTitle("识别校园 Wi-Fi")
                .setMessage("Android 将 Wi-Fi 名称归为位置相关信息。请允许“精确位置”，应用才能确认是 zut-stu；应用不读取 GPS 坐标。")
                .setPositiveButton("授权",(d,w)->requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},101))
                .setNegativeButton("暂不",null).show();
    }
    private void backgroundHelp() {
        new AlertDialog.Builder(this).setTitle("后台运行说明")
                .setMessage("后台重连由 Android 调度，最短间隔为 15 分钟，省电或休眠时可能更晚。定时登录也不保证精确到分钟。\n\n后台需要读取 Wi-Fi 名称；部分系统需要位置权限“始终允许”，并打开系统定位。应用不调用 GPS。\n\n可在应用设置中按需允许通知及后台运行；各品牌菜单不同。开启“重启后恢复”只恢复任务，不会自动弹出登录界面。")
                .setPositiveButton("打开应用设置",(d,w)->startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()))))
                .setNegativeButton("关闭",null).show();
    }
    @Override protected void onResume() {
        super.onResume(); refreshLog(); nextForegroundCheck=System.currentTimeMillis()+60000; ui.post(refresh);
        if (firstResume) { firstResume=false; if (store.ready() && store.p.getBoolean("reopen",true) && !store.paused()) ui.postDelayed(()->connect(false),400); }
    }
    @Override protected void onPause() { ui.removeCallbacksAndMessages(null); super.onPause(); }
    @Override protected void onDestroy() { if(engine!=null)engine.cancel(); super.onDestroy(); }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if(requestCode==101) { store.log(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED ? "Wi-Fi 识别授权完成，请点击连接。" : "未获得精确位置权限，暂时无法确认校园 Wi-Fi。"); refreshLog(); }
    }
}
