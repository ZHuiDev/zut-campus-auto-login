package cn.zhuidev.campus;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent intent) {
        Store store = new Store(c);
        if (store.p.getBoolean("boot", false)) Tasks.schedule(c);
    }
}
