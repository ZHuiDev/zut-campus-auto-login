package cn.zhuidev.campus;

import java.net.URI;
import java.util.Calendar;

/** Platform-independent policy, shared by the app and JVM tests. */
public final class Core {
    public static final String SSID = "zut-stu";
    public static final String PORTAL = "http://1.1.1.1/";
    public static final String DIRECT = "http://1.1.1.1/a70.htm";
    public static boolean approved(String url) {
        try {
            URI u = new URI(url);
            return ("http".equalsIgnoreCase(u.getScheme()) || "https".equalsIgnoreCase(u.getScheme()))
                    && u.getRawUserInfo() == null
                    && ("1.1.1.1".equals(u.getHost()) || "10.10.9.200".equals(u.getHost()));
        } catch (Exception e) { return false; }
    }
    public static String ssid(String raw) {
        if (raw == null || raw.equals("<unknown ssid>")) return "";
        if (raw.length() > 1 && raw.startsWith("\"") && raw.endsWith("\"")) return raw.substring(1, raw.length() - 1);
        return raw;
    }
    public static long nextDaily(long now, int hour, int minute) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(now);
        c.set(Calendar.HOUR_OF_DAY, Math.max(0, Math.min(23, hour)));
        c.set(Calendar.MINUTE, Math.max(0, Math.min(59, minute)));
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= now) c.add(Calendar.DAY_OF_YEAR, 1);
        return c.getTimeInMillis();
    }
    public static String errorKind(String text) {
        if (text == null) return "";
        if (text.contains("欠费") || text.contains("余额不足")) return "BALANCE";
        if (text.matches("(?is).*?(密码.{0,8}(错误|不正确)|账号或密码|用户名.{0,6}(错误|不存在)|账户.{0,6}(锁定|停用)|账号.{0,6}(锁定|停用)|认证失败|认证被拒绝|登录失败|登陆失败|password.{0,8}(wrong|incorrect|invalid)|authentication failed).*")) return "AUTH";
        if (text.contains("验证码")) return "CAPTCHA";
        return "";
    }
    public static boolean retry(int attempts, boolean online, String error) {
        return attempts < 2 && !online && (error == null || error.isEmpty());
    }
    public static int interval(int minutes) { return Math.max(15, Math.min(120, minutes)); }
    private Core() { }
}
