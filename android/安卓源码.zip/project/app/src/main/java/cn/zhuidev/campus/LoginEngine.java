package cn.zhuidev.campus;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JsResult;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
import org.json.JSONTokener;

/** All WebView work stays on the main thread; HTTP probes explicitly use Wi-Fi. */
public final class LoginEngine {
    public enum Result { ONLINE, SKIP, FAILURE, ATTENTION, CANCELLED }
    public interface Listener { void log(String text); void finished(Result result); }
    public static LoginEngine active;
    private final Context context;
    private final Store store;
    private final Listener listener;
    private final ViewGroup host;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ConcurrentLinkedQueue<HttpURLConnection> connections = new ConcurrentLinkedQueue<>();
    private ConnectivityManager cm;
    private Network wifi, previous;
    private WebView web;
    private boolean stopped, bound;
    private int generation, pass = 1, submissions;
    private String fillFunction, secret, lastAlert = "";
    private static final String ERROR_SCRIPT = "(function(){const t=document.body?document.body.innerText:'';if(/欠费|余额不足/.test(t))return 'BALANCE';if(/密码.{0,8}(错误|不正确)|账号或密码|用户名.{0,6}(错误|不存在)|账户.{0,6}(锁定|停用)|认证失败|认证被拒绝|登录失败|登陆失败|password.{0,8}(wrong|incorrect|invalid)|authentication failed/i.test(t))return 'AUTH';return '';})()";
    public LoginEngine(Context c, ViewGroup container, Listener l) { context = c; store = new Store(c); host = container; listener = l; }
    private void log(String message) { store.log(message); listener.log(message); }
    public void start(boolean manual) {
        if (active != null) { stopped = true; io.shutdownNow(); listener.finished(Result.SKIP); return; }
        active = this;
        main.postDelayed(() -> finish(Result.FAILURE, "本轮连接超时，已停止。"), 120000);
        try {
            if (!store.ready()) { finish(Result.SKIP, "请先填写账号、密码并保存。 "); return; }
            if (manual) store.reset();
            if (!manual && store.paused()) { finish(Result.SKIP, "自动任务已暂停，点击连接可恢复。 "); return; }
            if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                finish(Result.SKIP, "请先授权精确位置以识别 Wi-Fi 名称；应用不读取 GPS 坐标。"); return;
            }
            WifiManager wm = (WifiManager)context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            String ssid = wm == null || wm.getConnectionInfo() == null ? "" : Core.ssid(wm.getConnectionInfo().getSSID());
            if (ssid.isEmpty()) {
                finish(Result.SKIP, "无法读取 Wi-Fi 名称。请检查位置权限和系统定位开关；后台识别可能需要“始终允许”。"); return;
            }
            if (!Core.SSID.equals(ssid)) { finish(Result.SKIP, "当前 Wi-Fi 不是 zut-stu，请在系统设置中连接校园网络。"); return; }
            cm = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(n);
                if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) && !caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) { wifi = n; break; }
            }
            if (wifi == null) { finish(Result.SKIP, "未找到已连接的 Wi-Fi 网络。"); return; }
            previous = cm.getBoundNetworkForProcess();
            if (!cm.bindProcessToNetwork(wifi)) { finish(Result.FAILURE, "校园 Wi-Fi 已断开，请重新连接。"); return; }
            bound = true;
            secret = store.password();
            log("已识别 zut-stu，正在通过 Wi-Fi 检测互联网…");
            probe(online -> {
                if (online) finish(Result.ONLINE, "校园 Wi-Fi 已联网，无需重复登录。");
                else openBrowser();
            });
        } catch (Exception e) { finish(Result.FAILURE, "无法启动连接。请检查 Wi-Fi、权限和系统 WebView；若密码无法解密，请重新保存。"); }
    }
    private interface ProbeCallback { void result(boolean online); }
    private void probe(ProbeCallback callback) {
        if (stopped) return;
        io.execute(() -> {
            boolean ok = probeUrl("https://www.baidu.com/robots.txt", "User-agent: Baiduspider") || probeUrl("http://www.msftconnecttest.com/connecttest.txt", "Microsoft Connect Test");
            main.post(() -> { if (!stopped) callback.result(ok); });
        });
    }
    private boolean probeUrl(String url, String marker) {
        if (stopped) return false;
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection)wifi.openConnection(new URL(url), Proxy.NO_PROXY);
            connections.add(connection);
            connection.setConnectTimeout(3500); connection.setReadTimeout(3500); connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("User-Agent", "ZYUTCampusAndroid/1.0");
            if (connection.getResponseCode() != 200) return false;
            try (InputStream in = connection.getInputStream()) {
                byte[] buf = new byte[4096]; int count = in.read(buf);
                return count > 0 && new String(buf, 0, count, "UTF-8").contains(marker);
            }
        } catch (Exception e) { return false; }
        finally { if (connection != null) { connection.disconnect(); connections.remove(connection); } }
    }
    private String asset(String path) throws Exception {
        try (InputStream in = context.getAssets().open(path); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096]; int n; while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        }
    }
    private void openBrowser() {
        if (stopped) return;
        try {
            fillFunction = asset("fill.js");
            web = new WebView(context);
            configure(web);
            web.setWebChromeClient(new WebChromeClient() {
                @Override public boolean onJsAlert(WebView v, String url, String message, JsResult r) {
                    if (Core.approved(url)) lastAlert = message;
                    r.confirm(); return true;
                }
                @Override public boolean onJsConfirm(WebView v, String url, String message, JsResult r) { r.cancel(); return true; }
            });
            web.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                    return request.isForMainFrame() && !Core.approved(request.getUrl().toString());
                }
                @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail detail) {
                    finish(Result.FAILURE, "系统 WebView 进程退出，本轮连接已停止。"); return true;
                }
            });
            if (host != null) {
                host.removeAllViews(); host.setVisibility(View.VISIBLE);
                host.addView(web, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            } else {
                web.measure(View.MeasureSpec.makeMeasureSpec(1080, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(1600, View.MeasureSpec.EXACTLY));
                web.layout(0, 0, 1080, 1600); web.onResume();
            }
            navigate(Core.PORTAL, false);
        } catch (Exception e) { finish(Result.FAILURE, "登录页无法打开。请确认系统 WebView 已启用且可以正常使用。"); }
    }
    public static void configure(WebView v) {
        WebSettings s = v.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(false); s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setUseWideViewPort(true); s.setLoadWithOverviewMode(true);
        s.setBuiltInZoomControls(true); s.setDisplayZoomControls(false);
        s.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36");
        v.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
    }
    private void navigate(String url, boolean fallback) {
        if (stopped) return;
        log("正在载入学校登录页，第 " + pass + "/2 轮…");
        int g = ++generation;
        lastAlert = ""; web.loadUrl(url);
        main.postDelayed(() -> poll(g, 18, fallback), 1200);
    }
    private String decode(String value) {
        try { Object v = new JSONTokener(value).nextValue(); return v instanceof String ? (String)v : ""; }
        catch (Exception e) { return ""; }
    }
    private void poll(int g, int remaining, boolean fallback) {
        if (stopped || g != generation) return;
        if (remaining <= 0) {
            if (!fallback) navigate(Core.DIRECT, true);
            else finish(Result.FAILURE, "未识别到学校登录表单，未提交账号。请使用“查看登录页”检查。");
            return;
        }
        if (!Core.approved(web.getUrl())) { main.postDelayed(() -> poll(g, remaining - 1, fallback), 600); return; }
        try {
            JSONObject cfg = new JSONObject().put("account", store.account()).put("password", secret).put("carrier", store.carrier()).put("test", false).put("prepare", true);
            web.evaluateJavascript(fillFunction + "(" + cfg.toString() + ")", raw -> {
                if (stopped || g != generation) return;
                String state = decode(raw);
                switch (state) {
                    case "READY":
                        // Reserve the attempt before clicking: a navigation may destroy the JS context.
                        if (submissions >= 2) { finish(Result.FAILURE, "本轮已达到两次提交上限，已停止。"); break; }
                        submissions++;
                        web.evaluateJavascript("(function(){var b=window.__campusLoginButton;window.__campusLoginButton=null;if(b)b.click();})()", null);
                        log("已提交第 " + submissions + "/2 次登录，等待 Wi-Fi 联网…"); checkAfter(g, 3); break;
                    case "SESSION": log("登录页显示已有会话，正在验证 Wi-Fi 联网…"); checkAfter(g, 3); break;
                    case "CAPTCHA": finish(Result.ATTENTION, "登录页要求验证码，请打开登录页手动完成；自动任务已暂停。"); break;
                    case "CARRIER": finish(Result.ATTENTION, "未找到所选运营商，请核对学校网页；自动任务已暂停。"); break;
                    case "BUTTON": finish(Result.ATTENTION, "未识别到登录按钮，请核对学校网页；自动任务已暂停。"); break;
                    default: main.postDelayed(() -> poll(g, remaining - 1, fallback), 600);
                }
            });
        } catch (Exception e) { finish(Result.FAILURE, "网页操作失败，请更新系统 WebView 后重试。"); }
    }
    private void reject(String kind) {
        if (kind.equals("BALANCE")) finish(Result.ATTENTION, "网页提示欠费或余额不足，自动任务已暂停。");
        else if (kind.equals("CAPTCHA")) finish(Result.ATTENTION, "网页要求验证码，请手动登录；自动任务已暂停。");
        else finish(Result.ATTENTION, "网页提示认证失败，请核对账号、密码和联通选项；自动任务已暂停。");
    }
    private void checkAfter(int g, int remaining) {
        main.postDelayed(() -> {
            if (stopped || g != generation) return;
            String alert = Core.errorKind(lastAlert);
            if (!alert.isEmpty()) { reject(alert); return; }
            web.evaluateJavascript(ERROR_SCRIPT, raw -> {
                if (stopped || g != generation) return;
                String error = decode(raw);
                if (!error.isEmpty()) { reject(error); return; }
                probe(online -> {
                    if (online) { finish(Result.ONLINE, "连接成功，校园 Wi-Fi 的互联网检测已通过。"); return; }
                    if (remaining > 1) checkAfter(g, remaining - 1);
                    else if (Core.retry(pass, false, "")) {
                        pass++; log("第一次后仍未联网，正在准备第二次登录…"); navigate(Core.PORTAL, false);
                    } else finish(Result.FAILURE, "两次尝试后仍未联网，请打开学校登录页查看提示。");
                });
            });
        }, 1800);
    }
    public void cancel() { finish(Result.CANCELLED, "本次登录已停止。"); }
    private void finish(Result result, String message) {
        if (stopped) return;
        stopped = true; generation++; main.removeCallbacksAndMessages(null);
        for (HttpURLConnection c : connections) c.disconnect(); connections.clear(); io.shutdownNow();
        if (web != null) {
            try { web.stopLoading(); if (web.getParent() instanceof ViewGroup) ((ViewGroup)web.getParent()).removeView(web); web.destroy(); } catch (Exception ignored) { }
            web = null;
        }
        if (host != null) host.setVisibility(View.GONE);
        if (bound && cm != null) { try { if (result == Result.ONLINE) cm.reportNetworkConnectivity(wifi, true); cm.bindProcessToNetwork(previous); } catch (Exception ignored) { } }
        secret = null;
        if (active == this) active = null;
        if (result == Result.ATTENTION) { store.pause(); Tasks.cancel(context); }
        else if (result == Result.FAILURE && store.fail() >= 3) { message += " 连续三轮失败，后台任务已暂停。"; Tasks.cancel(context); }
        else if (result == Result.ONLINE) store.p.edit().putInt("failures", 0).apply();
        log(message); listener.finished(result);
    }
}
