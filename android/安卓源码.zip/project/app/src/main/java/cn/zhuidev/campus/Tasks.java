package cn.zhuidev.campus;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public final class Tasks {
    public static final int PERIODIC = 4101, DAILY = 4102;
    public static void cancel(Context c) { JobScheduler s = c.getSystemService(JobScheduler.class); if (s != null) { s.cancel(PERIODIC); s.cancel(DAILY); } }
    public static void schedule(Context c) {
        Store store = new Store(c);
        cancel(c);
        if (!store.ready() || store.paused()) return;
        JobScheduler s = c.getSystemService(JobScheduler.class);
        if (s == null) return;
        ComponentName service = new ComponentName(c, CampusJobService.class);
        boolean persisted = store.p.getBoolean("boot", false);
        if (store.p.getBoolean("reconnect", false)) {
            s.schedule(new JobInfo.Builder(PERIODIC, service).setPeriodic(Core.interval(store.p.getInt("minutes", 15)) * 60000L)
                    .setPersisted(persisted).build());
        }
        daily(c);
    }
    public static void daily(Context c) {
        Store store = new Store(c);
        if (!store.p.getBoolean("daily", false) || store.paused()) return;
        long now = System.currentTimeMillis();
        long due = Core.nextDaily(now, store.p.getInt("hour", 8), store.p.getInt("minute", 0));
        JobScheduler s = c.getSystemService(JobScheduler.class);
        if (s != null) s.schedule(new JobInfo.Builder(DAILY, new ComponentName(c, CampusJobService.class))
                .setMinimumLatency(due - now).setOverrideDeadline(due - now + 3600000L)
                .setPersisted(store.p.getBoolean("boot", false)).build());
    }
    public static void notifyAttention(Context c) {
        Store store = new Store(c);
        long now = System.currentTimeMillis();
        if (now - store.p.getLong("notified", 0) < 3600000) return;
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class); if (nm == null) return;
        nm.createNotificationChannel(new NotificationChannel("campus-status", "校园网连接提示", NotificationManager.IMPORTANCE_DEFAULT));
        PendingIntent open = PendingIntent.getActivity(c, 1, new Intent(c, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        nm.notify(4100, new Notification.Builder(c, "campus-status").setSmallIcon(R.drawable.ic_wifi).setContentTitle("校园网连接需要检查")
                .setContentText("请打开应用查看连接状态或权限提示。").setContentIntent(open).setAutoCancel(true).build());
        store.p.edit().putLong("notified", now).apply();
    }
    private Tasks() { }
}
