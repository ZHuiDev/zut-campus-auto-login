﻿param(
    [Parameter(Mandatory=$true)][string]$AndroidJar,
    [Parameter(Mandatory=$true)][string]$BuildTools,
    [string]$BuildDirectory = (Join-Path $PSScriptRoot 'build'),
    [string]$OutputApk = (Join-Path (Split-Path $PSScriptRoot -Parent) '校园网自动连接-安卓.apk')
)
$ErrorActionPreference = 'Stop'
$project = $PSScriptRoot
$AndroidJar = (Resolve-Path -LiteralPath $AndroidJar).Path
$BuildTools = (Resolve-Path -LiteralPath $BuildTools).Path
New-Item -ItemType Directory -Force -Path $BuildDirectory | Out-Null
$build = (Resolve-Path -LiteralPath $BuildDirectory).Path
$classes = Join-Path $build 'classes'
$generated = Join-Path $build 'generated'
$dex = Join-Path $build 'dex'
New-Item -ItemType Directory -Force -Path $classes,$generated,$dex | Out-Null
function Invoke-Checked { param([string]$Program,[string[]]$Arguments) & $Program @Arguments; if ($LASTEXITCODE -ne 0) { throw "Build step failed: $Program" } }
$aapt2 = Join-Path $BuildTools 'aapt2.exe'
$resources = Join-Path $build 'resources.zip'
Invoke-Checked $aapt2 @('compile','--dir',(Join-Path $project 'app\src\main\res'),'-o',$resources)
$baseApk = Join-Path $build 'base.apk'
$manifest = Join-Path $build 'AndroidManifest.xml'
[xml]$manifestXml = [IO.File]::ReadAllText((Join-Path $project 'app\src\main\AndroidManifest.xml'))
$manifestXml.DocumentElement.SetAttribute('package','cn.zhuidev.campus')
$manifestXml.Save($manifest)
Invoke-Checked $aapt2 @('link','-I',$AndroidJar,'--manifest',$manifest,'--auto-add-overlay','-R',$resources,'-A',(Join-Path $project 'app\src\main\assets'),'--java',$generated,'--min-sdk-version','26','--target-sdk-version','36','--version-code','1','--version-name','1.0','-o',$baseApk)
$sources = @(Get-ChildItem -LiteralPath (Join-Path $project 'app\src\main\java'),$generated -Recurse -Filter '*.java' -File | ForEach-Object { '"' + $_.FullName.Replace('\','/') + '"' })
$sourceList = Join-Path $build 'sources.txt'
[IO.File]::WriteAllLines($sourceList,$sources,[Text.UTF8Encoding]::new($false))
Invoke-Checked 'javac' @('--release','8','-encoding','UTF-8','-classpath',$AndroidJar,'-d',$classes,('@'+$sourceList))
$classJar = Join-Path $build 'classes.jar'
Invoke-Checked 'jar' @('cf',$classJar,'-C',$classes,'.')
Invoke-Checked 'java' @('-cp',(Join-Path $BuildTools 'lib\d8.jar'),'com.android.tools.r8.D8','--release','--lib',$AndroidJar,'--min-api','26','--output',$dex,$classJar)
$unsigned = Join-Path $build 'unsigned.apk'
Copy-Item -LiteralPath $baseApk -Destination $unsigned -Force
Invoke-Checked 'jar' @('uf',$unsigned,'-C',$dex,'classes.dex')
$aligned = Join-Path $build 'aligned.apk'
Invoke-Checked (Join-Path $BuildTools 'zipalign.exe') @('-f','-p','4',$unsigned,$aligned)
$keyFile = $env:CAMPUS_KEYSTORE
if ([string]::IsNullOrEmpty($keyFile)) {
    $keyFolder = Join-Path $project '.local-signing'
    New-Item -ItemType Directory -Force -Path $keyFolder | Out-Null
    $keyFile = Join-Path $keyFolder 'debug.keystore'
    $env:CAMPUS_KEYSTORE_PASSWORD = 'android'
}
if ([string]::IsNullOrEmpty($env:CAMPUS_KEYSTORE_PASSWORD)) { throw 'Set CAMPUS_KEYSTORE_PASSWORD for the selected signing key.' }
if (!(Test-Path -LiteralPath $keyFile)) {
    Invoke-Checked 'keytool' @('-genkeypair','-noprompt','-keystore',$keyFile,'-storepass:env','CAMPUS_KEYSTORE_PASSWORD','-keypass:env','CAMPUS_KEYSTORE_PASSWORD','-alias','androiddebugkey','-keyalg','RSA','-keysize','3072','-validity','10000','-dname','CN=ZYUT Campus Login,OU=Personal App,O=ZHuiDev,C=CN')
}
Invoke-Checked 'java' @('-jar',(Join-Path $BuildTools 'lib\apksigner.jar'),'sign','--ks',$keyFile,'--ks-key-alias','androiddebugkey','--ks-pass','env:CAMPUS_KEYSTORE_PASSWORD','--key-pass','env:CAMPUS_KEYSTORE_PASSWORD','--out',$OutputApk,$aligned)
Invoke-Checked 'java' @('-jar',(Join-Path $BuildTools 'lib\apksigner.jar'),'verify','--verbose','--print-certs',$OutputApk)
Write-Output $OutputApk
