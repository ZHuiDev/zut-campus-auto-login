package cn.zhuidev.campus;

import java.util.Calendar;
import java.util.TimeZone;

public final class CoreTests {
    private static int count;
    private static void check(boolean ok,String name){if(!ok)throw new AssertionError(name);System.out.println("PASS: "+name);count++;}
    private static long time(int y,int m,int d,int h,int minute){Calendar c=Calendar.getInstance();c.clear();c.set(y,m-1,d,h,minute);return c.getTimeInMillis();}
    public static void main(String[] args){
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Shanghai"));
        check(Core.approved("http://1.1.1.1/a70.htm?ip=10.133.1.2"),"Approved campus portal with dynamic IP");
        check(Core.approved("http://1.1.1.1:801/eportal/"),"Approved campus resource port");
        check(Core.approved("http://10.10.9.200/"),"Approved second campus gateway");
        check(!Core.approved("http://1.1.1.1.evil.example/a70.htm"),"Lookalike host rejected");
        check(!Core.approved("http://user@1.1.1.1/a70.htm"),"Embedded userinfo rejected");
        check(!Core.approved("javascript:alert(1)"),"Script navigation rejected");
        check(!Core.approved("file:///sdcard/index.html"),"Local file navigation rejected");
        check(!Core.approved("https://example.com/"),"Unrelated host rejected");
        check(Core.ssid("\"zut-stu\"").equals("zut-stu"),"Quoted Android SSID normalized");
        check(Core.ssid("<unknown ssid>").isEmpty(),"Redacted SSID requires permission");
        check(!Core.ssid("home-wifi").equals(Core.SSID),"Other Wi-Fi is not campus");
        check(Core.retry(1,false,""),"Offline first attempt allows second");
        check(!Core.retry(2,false,""),"Offline second attempt stops");
        check(!Core.retry(1,true,""),"Online first attempt stops");
        check(!Core.retry(1,false,"AUTH"),"Credential rejection prevents retry");
        check(Core.errorKind("密码错误").equals("AUTH"),"Wrong password alert classified");
        check(Core.errorKind("用户欠费，请充值").equals("BALANCE"),"Unpaid account stops login");
        check(Core.errorKind("请填写验证码").equals("CAPTCHA"),"CAPTCHA requires manual action");
        check(Core.errorKind("认证失败").equals("AUTH"),"Authentication rejection classified");
        check(Core.errorKind("登录成功").isEmpty(),"Success text is not an error");
        check(Core.nextDaily(time(2026,10,22,7,59),8,0)==time(2026,10,22,8,0),"Schedule today before target time");
        check(Core.nextDaily(time(2026,10,22,8,0),8,0)==time(2026,10,23,8,0),"Schedule next day after target is consumed");
        check(Core.nextDaily(time(2026,12,31,23,0),8,0)==time(2027,1,1,8,0),"Schedule crosses year boundary");
        check(Core.interval(1)==15 && Core.interval(999)==120,"Background interval stays within supported range");
        System.out.println("TOTAL: "+count+" passed");
    }
}
